"""
Investigation orchestrator.

General-purpose legal case investigator — covers ALL civil and criminal cases:
fraud, consumer harm, civil rights, discrimination, criminal, regulatory, and more.
No topic restrictions. Calls researchers directly in sequence.
"""

import sys
import time
from typing import Optional

import anthropic

from agents.court_researcher import run_court_researcher
from agents.documentor import run_documentor
from agents.web_researcher import run_web_researcher
from models.case_report import CaseIntelReport, SearchFilters

# Pause between agents to spread token usage across the TPM window
_INTER_AGENT_PAUSE = 6


def _build_court_query(query: str, filters: Optional[SearchFilters]) -> str:
    """Build a precise CourtListener query from the base query + active filters."""
    parts = [query]
    if filters:
        if filters.crime_types:
            parts.append(" ".join(filters.crime_types))
        if filters.protected_classes:
            parts.append(" ".join(filters.protected_classes))
        if filters.area:
            parts.append(filters.area)
    return " ".join(parts)


def _build_web_query(query: str, filters: Optional[SearchFilters]) -> str:
    """Build a web search query enriched with filter terms."""
    parts = [query]
    if filters:
        if filters.crime_types:
            parts.append(" ".join(filters.crime_types))
        if filters.protected_classes:
            parts.append(" ".join(filters.protected_classes))
        if filters.area:
            parts.append(filters.area)
        if filters.court_label:
            parts.append(filters.court_label)
    return " ".join(parts)


def run_investigation(
    query: str,
    filters: Optional[SearchFilters] = None,
    verbose: bool = False,
    client: Optional[anthropic.Anthropic] = None,
) -> CaseIntelReport:
    """
    Run a full investigation.

    1. Court researcher  — searches CourtListener + Descrybe
    2. Web researcher    — searches FTC / SEC / CFPB / news
    3. Documentor        — synthesizes both into a CaseIntelReport
    """
    if client is None:
        client = anthropic.Anthropic()

    def log(msg: str) -> None:
        if verbose:
            print(f"[investigation] {msg}", file=sys.stderr, flush=True)

    court_query = _build_court_query(query, filters)
    web_query   = _build_web_query(query, filters)

    # ── 1. Court research ─────────────────────────────────────────────────────
    log(f"Court researcher: {court_query[:100]}")
    court_findings: dict = {}
    try:
        court_findings = run_court_researcher(
            query=court_query,
            court_code=filters.court_code if filters else None,
            date_from=filters.date_from if filters else None,
            date_to=filters.date_to if filters else None,
            client=client,
        )
        n = court_findings.get("total_found", len(court_findings.get("cases", [])))
        log(f"Court researcher: {n} cases found")
    except Exception as e:
        log(f"Court researcher error: {e}")
        court_findings = {"cases": [], "total_found": 0, "error": str(e)}

    log(f"Pausing {_INTER_AGENT_PAUSE}s…")
    time.sleep(_INTER_AGENT_PAUSE)

    # ── 2. Web research ───────────────────────────────────────────────────────
    log(f"Web researcher: {web_query[:100]}")
    web_findings: dict = {}
    try:
        web_findings = run_web_researcher(query=web_query, client=client)
        n = web_findings.get("total_found", len(web_findings.get("findings", [])))
        log(f"Web researcher: {n} findings")
    except Exception as e:
        log(f"Web researcher error: {e}")
        web_findings = {"findings": [], "total_found": 0, "error": str(e)}

    log(f"Pausing {_INTER_AGENT_PAUSE}s…")
    time.sleep(_INTER_AGENT_PAUSE)

    # ── 3. Synthesis ──────────────────────────────────────────────────────────
    log("Documentor: synthesizing…")
    report = run_documentor(
        query=query,
        court_findings=court_findings,
        web_findings=web_findings,
        filters=filters,
        client=client,
    )
    log(f"Done — {report.total_cases_found} cases, {report.high_severity_count} high severity")
    return report
