#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# LegalPerigee — macOS Conflict & Health Checker
# Called by the .app launcher before starting the server.
# Detects and resolves conflicts silently where possible; prompts only when
# user input is needed.
# ─────────────────────────────────────────────────────────────────────────────

PROJECT_DIR="$1"
VERSION="1.1"
LOG="$HOME/Library/Logs/LegalPerigee_install.log"
VENV="$PROJECT_DIR/.venv"
VENV_PY="$VENV/bin/python3"
REQUIREMENTS="$PROJECT_DIR/requirements.txt"

log() { echo "[$(date '+%H:%M:%S')] $*" | tee -a "$LOG"; }
alert() {
    osascript -e "display alert \"LegalPerigee\" message \"$*\" as warning" 2>/dev/null || true
}
fatal() {
    osascript -e "display alert \"LegalPerigee — Setup Failed\" message \"$*\" as critical" 2>/dev/null || true
    log "FATAL: $*"
    exit 1
}

log "=== LegalPerigee v$VERSION startup check ==="
cd "$PROJECT_DIR" || fatal "Project folder not found at $PROJECT_DIR"

# ── 1. Port conflict ──────────────────────────────────────────────────────────
PIDS=$(lsof -ti:8501 2>/dev/null || true)
if [ -n "$PIDS" ]; then
    log "Port 8501 in use (PIDs: $PIDS) — killing stale processes"
    echo "$PIDS" | xargs kill -9 2>/dev/null || true
    sleep 0.5
fi

# ── 2. Find Python (arm64 preferred) ─────────────────────────────────────────
PYTHON=""
for candidate in \
    /opt/homebrew/opt/python@3.12/bin/python3.12 \
    /opt/homebrew/opt/python@3.11/bin/python3.11 \
    /opt/homebrew/bin/python3 \
    /usr/bin/python3; do
    [ -x "$candidate" ] || continue
    arch=$("$candidate" -c 'import platform; print(platform.machine())' 2>/dev/null)
    [ "$arch" = "arm64" ] || continue
    PYTHON="$candidate"
    break
done

[ -z "$PYTHON" ] && fatal "Python 3.9+ (arm64) not found.\n\nInstall via Homebrew:\n  brew install python@3.11"
log "Python: $PYTHON ($($PYTHON --version 2>&1))"

# ── 3. Virtual environment conflict check ─────────────────────────────────────
REBUILD_VENV=false

if [ ! -d "$VENV" ]; then
    log "No .venv found — will create"
    REBUILD_VENV=true

elif [ ! -x "$VENV_PY" ]; then
    log ".venv exists but python3 missing — rebuilding"
    REBUILD_VENV=true

else
    # Check architecture matches
    VENV_ARCH=$("$VENV_PY" -c 'import platform; print(platform.machine())' 2>/dev/null || echo "unknown")
    if [ "$VENV_ARCH" != "arm64" ]; then
        log ".venv is $VENV_ARCH, need arm64 — rebuilding"
        REBUILD_VENV=true
    fi

    # Check key packages are importable
    if ! "$VENV_PY" -c "import streamlit, anthropic, pydantic" 2>/dev/null; then
        log "Core packages missing from .venv — rebuilding"
        REBUILD_VENV=true
    fi
fi

# ── 4. Rebuild venv if needed ─────────────────────────────────────────────────
if [ "$REBUILD_VENV" = "true" ]; then
    log "Building virtual environment..."

    # Preserve the database before any rebuild
    DB_BACKUP=""
    if [ -f "$PROJECT_DIR/data/cases.db" ]; then
        DB_BACKUP="/tmp/legalperigee_cases_backup_$(date +%s).db"
        cp "$PROJECT_DIR/data/cases.db" "$DB_BACKUP"
        log "Database backed up to $DB_BACKUP"
    fi

    # Remove old venv
    rm -rf "$VENV"

    # Create new one with forced arm64
    arch -arm64 "$PYTHON" -m venv "$VENV" || fatal "Could not create virtual environment"
    arch -arm64 "$VENV/bin/pip" install --upgrade pip --quiet || true
    arch -arm64 "$VENV/bin/pip" install -r "$REQUIREMENTS" \
        || fatal "Dependency install failed.\n\nCheck $LOG for details.\n\nFix: bash $PROJECT_DIR/setup.sh"

    # Restore database
    if [ -n "$DB_BACKUP" ] && [ -f "$DB_BACKUP" ]; then
        mkdir -p "$PROJECT_DIR/data"
        cp "$DB_BACKUP" "$PROJECT_DIR/data/cases.db"
        log "Database restored"
        rm -f "$DB_BACKUP"
    fi

    log "Virtual environment ready"
fi

# ── 5. Upgrade check — new packages since last run ───────────────────────────
# Compare requirements hash to detect if deps changed (e.g. after update)
REQ_HASH=$(md5 -q "$REQUIREMENTS" 2>/dev/null || md5sum "$REQUIREMENTS" 2>/dev/null | cut -d' ' -f1)
HASH_FILE="$VENV/.req_hash"
STORED_HASH=$(cat "$HASH_FILE" 2>/dev/null || echo "")

if [ "$REQ_HASH" != "$STORED_HASH" ]; then
    log "requirements.txt changed — upgrading packages..."
    arch -arm64 "$VENV/bin/pip" install -r "$REQUIREMENTS" --quiet 2>&1 | tail -3
    echo "$REQ_HASH" > "$HASH_FILE"
    log "Package upgrade complete"
fi

# ── 6. Database integrity ─────────────────────────────────────────────────────
if [ -f "$PROJECT_DIR/data/cases.db" ]; then
    # Quick SQLite integrity check
    if ! "$VENV_PY" -c "
import sqlite3, sys
try:
    c = sqlite3.connect('$PROJECT_DIR/data/cases.db')
    c.execute('PRAGMA integrity_check').fetchone()
    c.close()
except Exception as e:
    print(f'DB corrupt: {e}', file=sys.stderr)
    sys.exit(1)
" 2>/dev/null; then
        log "Database corrupt — resetting (data will be re-synced)"
        mv "$PROJECT_DIR/data/cases.db" "$PROJECT_DIR/data/cases.db.corrupt.$(date +%s)"
    fi
fi

# ── 7. .env check ─────────────────────────────────────────────────────────────
ENV_FILE="$PROJECT_DIR/.env"
if [ ! -f "$ENV_FILE" ]; then
    log ".env missing — creating from template"
    cat > "$ENV_FILE" << 'ENVEOF'
# LegalPerigee configuration
# API key is stored in macOS Keychain — enter it in the app sidebar.
# COURTLISTENER_API_TOKEN=
# ALERT_EMAIL_FROM=
# ALERT_EMAIL_PASSWORD=
# ALERT_SMTP_HOST=smtp.gmail.com
# ALERT_SMTP_PORT=587
ENVEOF
fi

log "All checks passed — starting LegalPerigee v$VERSION"
exit 0
