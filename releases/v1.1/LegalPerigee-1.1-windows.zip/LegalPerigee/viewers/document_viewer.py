"""
LegalPerigee Document Viewer — format-specific rendering helpers.

Handles: PDF, DOCX, XLSX/XLS, CSV, PPTX, images, TXT, MD, JSON,
         HTML, XML, HEIC, video, and common code files.

PDF rendering: Uses text extraction (reliable in all environments including
pywebview/WKWebView) with a prominent download button. For attorneys who
need to annotate or share PDFs, download opens in their preferred PDF reader.
"""

from __future__ import annotations

import base64
import io
import json
import os
import tempfile
from pathlib import Path
from typing import Optional

import streamlit as st
import streamlit.components.v1 as components

# ── Format metadata ───────────────────────────────────────────────────────────

MIME_MAP: dict[str, str] = {
    ".pdf":      "application/pdf",
    ".docx":     "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".doc":      "application/msword",
    ".xlsx":     "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".xls":      "application/vnd.ms-excel",
    ".csv":      "text/csv",
    ".pptx":     "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".ppt":      "application/vnd.ms-powerpoint",
    ".png":      "image/png",
    ".jpg":      "image/jpeg",
    ".jpeg":     "image/jpeg",
    ".gif":      "image/gif",
    ".webp":     "image/webp",
    ".bmp":      "image/bmp",
    ".svg":      "image/svg+xml",
    ".heic":     "image/heic",
    ".heif":     "image/heif",
    ".tiff":     "image/tiff",
    ".tif":      "image/tiff",
    ".mov":      "video/quicktime",
    ".qt":       "video/quicktime",
    ".mp4":      "video/mp4",
    ".m4v":      "video/mp4",
    ".avi":      "video/x-msvideo",
    ".mkv":      "video/x-matroska",
    ".webm":     "video/webm",
    ".txt":      "text/plain",
    ".md":       "text/markdown",
    ".markdown": "text/markdown",
    ".json":     "application/json",
    ".html":     "text/html",
    ".htm":      "text/html",
    ".xml":      "application/xml",
    ".py":       "text/x-python",
    ".js":       "text/javascript",
    ".ts":       "text/typescript",
    ".css":      "text/css",
    ".yaml":     "text/yaml",
    ".yml":      "text/yaml",
    ".toml":     "application/toml",
    ".rtf":      "application/rtf",
    ".odt":      "application/vnd.oasis.opendocument.text",
}

TYPE_ICONS: dict[str, str] = {
    ".pdf": "📄", ".docx": "📝", ".doc": "📝",
    ".xlsx": "📊", ".xls": "📊", ".csv": "📊",
    ".pptx": "📊", ".ppt": "📊",
    ".png": "🖼️", ".jpg": "🖼️", ".jpeg": "🖼️",
    ".gif": "🖼️", ".webp": "🖼️", ".bmp": "🖼️", ".svg": "🖼️",
    ".heic": "🖼️", ".heif": "🖼️", ".tiff": "🖼️", ".tif": "🖼️",
    ".mov": "🎬", ".qt": "🎬", ".mp4": "🎬", ".m4v": "🎬",
    ".avi": "🎬", ".mkv": "🎬", ".webm": "🎬",
    ".txt": "📃", ".md": "📃", ".markdown": "📃", ".rtf": "📃",
    ".json": "{ }", ".html": "🌐", ".htm": "🌐", ".xml": "📃",
    ".py": "🐍", ".js": "📜", ".ts": "📜", ".css": "🎨",
    ".yaml": "📃", ".yml": "📃", ".toml": "📃",
}

CODE_LANGS: dict[str, str] = {
    ".py": "python", ".js": "javascript", ".ts": "typescript",
    ".css": "css", ".html": "html", ".htm": "html",
    ".xml": "xml", ".json": "json",
    ".yaml": "yaml", ".yml": "yaml", ".toml": "toml",
    ".md": "markdown", ".markdown": "markdown",
    ".txt": "text",
}

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".svg",
              ".heic", ".heif", ".tiff", ".tif"}
VIDEO_EXTS = {".mp4", ".mov", ".qt", ".m4v", ".avi", ".mkv", ".webm", ".3gp"}


def ext(name: str) -> str:
    return Path(name).suffix.lower()

def mime_for(name: str) -> str:
    return MIME_MAP.get(ext(name), "application/octet-stream")

def icon_for(name: str) -> str:
    return TYPE_ICONS.get(ext(name), "📁")

def fmt_size(n: int) -> str:
    if n < 1024:         return f"{n} B"
    if n < 1024 ** 2:    return f"{n/1024:.1f} KB"
    if n < 1024 ** 3:    return f"{n/1024**2:.1f} MB"
    return f"{n/1024**3:.1f} GB"


# ── Download bar ──────────────────────────────────────────────────────────────

def _download_bar(name: str, data: bytes, label: str = "⬇️ Download") -> None:
    col_info, col_btn = st.columns([5, 1])
    with col_info:
        st.markdown(
            f'<div style="background:#f0f4ff;border:1px solid #c5d0e8;border-radius:6px;'
            f'padding:.4rem .8rem;font-size:.85rem;">'
            f'{icon_for(name)} &nbsp;<strong>{name}</strong> &nbsp;·&nbsp; '
            f'{fmt_size(len(data))} &nbsp;·&nbsp; {mime_for(name)}'
            f'</div>',
            unsafe_allow_html=True,
        )
    with col_btn:
        st.download_button(
            label,
            data=data,
            file_name=name,
            mime=mime_for(name),
            use_container_width=True,
            key=f"dl_{name}_{len(data)}",
        )


# ── PDF ───────────────────────────────────────────────────────────────────────

def render_pdf(name: str, data: bytes) -> None:
    """
    Render a PDF. Primary display is full text extraction (works in all
    environments including pywebview/WKWebView). Embedded viewer provided
    as an option — open in external app for annotation.
    """
    _download_bar(name, data, "⬇️ Open in PDF Reader")
    st.caption("💡 Click **Open in PDF Reader** to view with full fidelity, annotations, and search.")

    tab_text, tab_embedded = st.tabs(["📃 Extracted Text", "🖥️ Embedded Viewer"])

    with tab_text:
        _render_pdf_text(data)

    with tab_embedded:
        st.caption("Note: The embedded viewer may not display in all environments. "
                   "Use **Open in PDF Reader** for the best experience.")
        try:
            if len(data) <= 20 * 1024 * 1024:  # 20 MB limit for embedding
                b64 = base64.b64encode(data).decode()
                # Use <object> tag — more reliable than iframe for PDFs
                obj_html = (
                    f'<object data="data:application/pdf;base64,{b64}" '
                    f'type="application/pdf" width="100%" height="850px" '
                    f'style="border:none;border-radius:8px;">'
                    f'<p>PDF cannot be displayed inline. '
                    f'<a href="data:application/pdf;base64,{b64}" '
                    f'download="{name}">Download {name}</a></p>'
                    f'</object>'
                )
                components.html(obj_html, height=860, scrolling=False)
            else:
                st.info("File too large for inline preview (>20 MB). Use **Open in PDF Reader** above.", icon="📄")
        except Exception as e:
            st.warning(f"Embedded viewer unavailable: {e}. Use the download button.", icon="⚠️")


def _render_pdf_text(data: bytes) -> None:
    """Extract and display all text from a PDF, page by page."""
    try:
        import pdfplumber
        with pdfplumber.open(io.BytesIO(data)) as pdf:
            if not pdf.pages:
                st.info("PDF has no extractable text pages.")
                return

            st.caption(f"📄 {len(pdf.pages)} pages")

            # Global search within extracted text
            search_term = st.text_input(
                "Search within document",
                placeholder="Enter text to find...",
                key=f"pdf_search_{len(data)}",
            )

            all_text_pages = []
            for i, page in enumerate(pdf.pages, 1):
                text = page.extract_text() or ""
                all_text_pages.append((i, text))

            if search_term:
                matches = [(i, t) for i, t in all_text_pages
                           if search_term.lower() in t.lower()]
                st.success(f"Found '{search_term}' on {len(matches)} page(s)")
                pages_to_show = matches
            else:
                pages_to_show = all_text_pages

            for page_num, text in pages_to_show:
                with st.expander(f"Page {page_num}", expanded=(len(pages_to_show) <= 3)):
                    if text.strip():
                        if search_term:
                            # Highlight search term
                            highlighted = text.replace(
                                search_term,
                                f"**{search_term}**"
                            )
                            st.markdown(highlighted)
                        else:
                            st.text(text)
                    else:
                        st.caption("(No extractable text on this page — may be a scanned image)")

    except ImportError:
        st.warning("pdfplumber not installed. Use the download button to open externally.", icon="⚠️")
    except Exception as e:
        st.error(f"Could not extract PDF text: {e}")
        st.info("Use the **Open in PDF Reader** button above to view this file.", icon="📄")


# ── DOCX ──────────────────────────────────────────────────────────────────────

def render_docx(name: str, data: bytes) -> None:
    _download_bar(name, data)
    try:
        from docx import Document
        from docx.table import Table
        from docx.text.paragraph import Paragraph
    except ImportError:
        st.error("python-docx not installed.")
        return

    try:
        doc = Document(io.BytesIO(data))
    except Exception as e:
        st.error(f"Could not open DOCX: {e}")
        return

    tab_rendered, tab_raw = st.tabs(["📄 Rendered", "📃 Raw Text"])

    with tab_rendered:
        for block in doc.element.body:
            tag = block.tag.split("}")[-1]
            if tag == "p":
                try:
                    para = Paragraph(block, doc)
                    text = para.text
                    if not text.strip():
                        continue
                    style = para.style.name if para.style else ""
                    if style.startswith("Heading 1"):
                        st.markdown(f"# {text}")
                    elif style.startswith("Heading 2"):
                        st.markdown(f"## {text}")
                    elif style.startswith("Heading 3"):
                        st.markdown(f"### {text}")
                    else:
                        st.write(text)
                except Exception:
                    pass
            elif tag == "tbl":
                try:
                    tbl = Table(block, doc)
                    rows = [[cell.text for cell in row.cells] for row in tbl.rows]
                    if rows:
                        import pandas as pd
                        df = pd.DataFrame(rows[1:], columns=rows[0]) if len(rows) > 1 else pd.DataFrame(rows)
                        st.dataframe(df, use_container_width=True)
                except Exception:
                    pass

    with tab_raw:
        full_text = "\n".join(p.text for p in doc.paragraphs if p.text.strip())
        st.text_area("Full text", full_text, height=600, label_visibility="collapsed")


# ── XLSX / XLS ────────────────────────────────────────────────────────────────

def render_xlsx(name: str, data: bytes) -> None:
    _download_bar(name, data)
    try:
        import pandas as pd
    except ImportError:
        st.error("pandas not installed.")
        return

    try:
        engine = "openpyxl" if name.lower().endswith(".xlsx") else "xlrd"
        sheets = pd.read_excel(io.BytesIO(data), sheet_name=None, engine=engine)
    except Exception as e:
        st.error(f"Could not open workbook: {e}")
        return

    if not sheets:
        st.info("Workbook is empty.")
        return

    sheet_names = list(sheets.keys())
    if len(sheet_names) == 1:
        df = sheets[sheet_names[0]]
        st.caption(f"Sheet: {sheet_names[0]} · {len(df):,} rows × {len(df.columns):,} columns")
        st.dataframe(df, use_container_width=True, height=520)
    else:
        tabs = st.tabs([f"📋 {s}" for s in sheet_names])
        for tab, sname in zip(tabs, sheet_names):
            with tab:
                df = sheets[sname]
                st.caption(f"{len(df):,} rows × {len(df.columns):,} columns")
                st.dataframe(df, use_container_width=True, height=520)


# ── CSV ───────────────────────────────────────────────────────────────────────

def render_csv(name: str, data: bytes) -> None:
    _download_bar(name, data)
    try:
        import pandas as pd
        df = pd.read_csv(io.BytesIO(data))
    except Exception as e:
        st.error(f"Could not parse CSV: {e}")
        return

    st.caption(f"{len(df):,} rows × {len(df.columns):,} columns")

    fc, fs = st.columns([3, 2])
    with fc:
        search = st.text_input("Filter rows", placeholder="Any column contains...",
                               key=f"csv_f_{len(data)}")
    with fs:
        sort_col = st.selectbox("Sort by", ["— none —"] + list(df.columns),
                                key=f"csv_s_{len(data)}")

    if search:
        mask = df.apply(lambda c: c.astype(str).str.contains(search, case=False, na=False)).any(axis=1)
        df = df[mask]
    if sort_col != "— none —":
        df = df.sort_values(sort_col)

    st.dataframe(df, use_container_width=True, height=520)


# ── PPTX ──────────────────────────────────────────────────────────────────────

def render_pptx(name: str, data: bytes) -> None:
    _download_bar(name, data)
    try:
        from pptx import Presentation
    except ImportError:
        st.error("python-pptx not installed.")
        return

    try:
        prs = Presentation(io.BytesIO(data))
    except Exception as e:
        st.error(f"Could not open PPTX: {e}")
        return

    slides = prs.slides
    total  = len(slides)
    if total == 0:
        st.info("Presentation has no slides.")
        return

    st.caption(f"{total} slides")
    slide_num = st.slider("Slide", 1, total, 1, key=f"pptx_{len(data)}")
    slide = slides[slide_num - 1]

    with st.container():
        st.markdown(
            '<div style="background:#fff;border:1px solid #dde3ee;border-radius:8px;'
            'padding:1.5rem 2rem;min-height:320px;">',
            unsafe_allow_html=True,
        )
        for shape in slide.shapes:
            if not shape.has_text_frame:
                continue
            for para in shape.text_frame.paragraphs:
                text = para.text.strip()
                if not text:
                    continue
                try:
                    pts = para.runs[0].font.size.pt if para.runs and para.runs[0].font.size else 0
                except Exception:
                    pts = 0
                if pts >= 24:
                    st.markdown(f"## {text}")
                elif pts >= 18:
                    st.markdown(f"### {text}")
                else:
                    st.write(text)
        st.markdown("</div>", unsafe_allow_html=True)

    with st.expander("All slides — text"):
        for i, sl in enumerate(slides, 1):
            texts = [s.text_frame.text.strip() for s in sl.shapes if s.has_text_frame]
            st.markdown(f"**Slide {i}**")
            st.text("\n".join(t for t in texts if t) or "(no text)")
            st.divider()


# ── Images ────────────────────────────────────────────────────────────────────

def render_image(name: str, data: bytes) -> None:
    _download_bar(name, data)
    suffix = ext(name)

    if suffix == ".svg":
        b64 = base64.b64encode(data).decode()
        st.markdown(
            f'<img src="data:image/svg+xml;base64,{b64}" '
            f'style="max-width:100%;border-radius:8px;" />',
            unsafe_allow_html=True,
        )
    elif suffix in (".heic", ".heif"):
        try:
            from pillow_heif import register_heif_opener
            register_heif_opener()
            from PIL import Image as _PIL
            img = _PIL.open(io.BytesIO(data)).convert("RGB")
            buf = io.BytesIO()
            img.save(buf, format="JPEG", quality=90)
            st.image(buf.getvalue(), use_container_width=True,
                     caption=f"{name} (converted from HEIC)")
        except Exception as e:
            st.error(f"Could not display HEIC: {e}")
    elif suffix in (".tiff", ".tif"):
        try:
            from PIL import Image as _PIL
            img = _PIL.open(io.BytesIO(data)).convert("RGB")
            buf = io.BytesIO()
            img.save(buf, format="JPEG", quality=90)
            st.image(buf.getvalue(), use_container_width=True)
        except Exception as e:
            st.error(f"Could not display TIFF: {e}")
    else:
        st.image(data, use_container_width=True)
    st.caption(fmt_size(len(data)))


def render_video(name: str, data: bytes) -> None:
    _download_bar(name, data, "⬇️ Download Video")
    try:
        st.video(data)
    except Exception as e:
        st.info(f"Inline preview unavailable ({e}). Download to view.", icon="🎬")


# ── Markdown ──────────────────────────────────────────────────────────────────

def render_markdown(name: str, data: bytes) -> None:
    _download_bar(name, data)
    text = data.decode("utf-8", errors="replace")
    tab_r, tab_raw = st.tabs(["📄 Rendered", "📃 Raw"])
    with tab_r:
        st.markdown(text)
    with tab_raw:
        st.code(text, language="markdown")


# ── JSON ──────────────────────────────────────────────────────────────────────

def render_json(name: str, data: bytes) -> None:
    _download_bar(name, data)
    text = data.decode("utf-8", errors="replace")
    try:
        parsed = json.loads(text)
        pretty = json.dumps(parsed, indent=2, ensure_ascii=False)
        tab_p, tab_r = st.tabs(["📄 Pretty", "📃 Raw"])
        with tab_p:
            st.code(pretty, language="json")
        with tab_r:
            st.code(text, language="json")
        if isinstance(parsed, dict):
            st.caption(f"Keys: {', '.join(str(k) for k in list(parsed.keys())[:20])}")
        elif isinstance(parsed, list):
            st.caption(f"Array with {len(parsed):,} items")
    except json.JSONDecodeError:
        st.warning("Not valid JSON — showing as plain text.")
        st.code(text, language="text")


# ── HTML ──────────────────────────────────────────────────────────────────────

def render_html(name: str, data: bytes) -> None:
    _download_bar(name, data)
    html_str = data.decode("utf-8", errors="replace")
    tab_p, tab_s = st.tabs(["🌐 Preview", "📃 Source"])
    with tab_p:
        components.html(html_str, height=700, scrolling=True)
    with tab_s:
        st.code(html_str, language="html")


# ── Plain text / code ─────────────────────────────────────────────────────────

def render_text(name: str, data: bytes) -> None:
    _download_bar(name, data)
    text = data.decode("utf-8", errors="replace")
    lang = CODE_LANGS.get(ext(name), "text")
    st.code(text, language=lang)


# ── Main dispatcher ───────────────────────────────────────────────────────────

def render_file(name: str, data: bytes) -> None:
    """Route a file to the correct viewer based on its extension."""
    if not data:
        st.warning(f"File '{name}' is empty.")
        return

    suffix = ext(name)

    try:
        if suffix == ".pdf":
            render_pdf(name, data)
        elif suffix in (".docx", ".doc", ".odt"):
            render_docx(name, data)
        elif suffix in (".xlsx", ".xls"):
            render_xlsx(name, data)
        elif suffix == ".csv":
            render_csv(name, data)
        elif suffix in (".pptx", ".ppt"):
            render_pptx(name, data)
        elif suffix in IMAGE_EXTS:
            render_image(name, data)
        elif suffix in VIDEO_EXTS:
            render_video(name, data)
        elif suffix in (".md", ".markdown"):
            render_markdown(name, data)
        elif suffix == ".json":
            render_json(name, data)
        elif suffix in (".html", ".htm"):
            render_html(name, data)
        else:
            render_text(name, data)
    except Exception as e:
        st.error(f"Error rendering '{name}': {e}")
        _download_bar(name, data, "⬇️ Download (rendering failed)")
