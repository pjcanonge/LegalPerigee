#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# LegalPerigee v1.1 — Self-Contained Release Builder
#
# Creates distributable packages that work on ANY machine:
#   macOS: LegalPerigee-1.1-mac.dmg    (drag-to-Applications, zero setup)
#   Windows: LegalPerigee-1.1-win/     (run setup.ps1, one-click install)
#
# Both packages include ALL project files — no pre-installed project folder needed.
# ─────────────────────────────────────────────────────────────────────────────

set -e
cd "$(dirname "${BASH_SOURCE[0]}")/.."

PROJECT_DIR="$(pwd)"
VERSION="1.1"
RELEASE_DIR="$PROJECT_DIR/releases/v$VERSION"
MAC_STAGE="$RELEASE_DIR/mac_staging"
WIN_STAGE="$RELEASE_DIR/win_staging"

echo ""
echo "⚖️  LegalPerigee v$VERSION — Release Builder"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# ── Clean release directory ───────────────────────────────────────────────────
rm -rf "$RELEASE_DIR"
mkdir -p "$MAC_STAGE" "$WIN_STAGE"


# ═══════════════════════════════════════════════════════════════════════════════
# macOS — Self-contained .app
# ═══════════════════════════════════════════════════════════════════════════════
echo "🍎  Building macOS package..."

APP_BUNDLE="$MAC_STAGE/LegalPerigee.app"
APP_CONTENTS="$APP_BUNDLE/Contents"
APP_MACOS="$APP_CONTENTS/MacOS"
APP_RES="$APP_CONTENTS/Resources"
APP_CODE="$APP_RES/app"           # all project code lives here

mkdir -p "$APP_MACOS" "$APP_RES" "$APP_CODE"

# ── Copy all project files into the bundle ────────────────────────────────────
echo "  Copying project files..."
rsync -a \
    --exclude ".venv" \
    --exclude ".git" \
    --exclude "__pycache__" \
    --exclude "*.pyc" \
    --exclude ".DS_Store" \
    --exclude "releases" \
    --exclude "node_modules" \
    --exclude "dist" \
    --exclude "data/*.db" \
    --exclude "*.repair_backup" \
    "$PROJECT_DIR/" "$APP_CODE/"

# Copy icons
cp "$PROJECT_DIR/AppIcon.icns"   "$APP_RES/AppIcon.icns"
cp "$PROJECT_DIR/data/logo.png"  "$APP_RES/logo.png"  2>/dev/null || true

# ── Info.plist ────────────────────────────────────────────────────────────────
cat > "$APP_CONTENTS/Info.plist" << 'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleExecutable</key>   <string>LegalPerigee</string>
  <key>CFBundleIconFile</key>     <string>AppIcon</string>
  <key>CFBundleIdentifier</key>   <string>ai.legalperigee.app</string>
  <key>CFBundleName</key>         <string>LegalPerigee</string>
  <key>CFBundleDisplayName</key>  <string>LegalPerigee</string>
  <key>CFBundlePackageType</key>  <string>APPL</string>
  <key>CFBundleShortVersionString</key> <string>1.1</string>
  <key>CFBundleVersion</key>      <string>1</string>
  <key>LSMinimumSystemVersion</key> <string>12.0</string>
  <key>NSHighResolutionCapable</key> <true/>
</dict>
</plist>
PLIST

# ── Self-contained launcher ───────────────────────────────────────────────────
# This launcher finds Python, sets up the venv INSIDE the bundle, and launches.
cat > "$APP_MACOS/LegalPerigee" << 'LAUNCHER'
#!/bin/bash
# LegalPerigee v1.1 — Self-Contained Launcher
# Project is embedded at Contents/Resources/app/

# Resolve bundle paths regardless of where the .app was placed
BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
APP_CODE="$BUNDLE_DIR/Contents/Resources/app"
VENV_DIR="$APP_CODE/.venv"
LOG_FILE="$HOME/Library/Logs/LegalPerigee.log"
CHECKER="$APP_CODE/installers/macos/first_run_check.sh"

# Data directory in user home (persists across updates)
DATA_DIR="$HOME/Library/Application Support/LegalPerigee"
mkdir -p "$DATA_DIR"

# Symlink data dir so db/logs go to user space
if [ ! -L "$APP_CODE/data" ]; then
    [ -d "$APP_CODE/data" ] && cp -r "$APP_CODE/data" "$DATA_DIR/" 2>/dev/null || true
    rm -rf "$APP_CODE/data"
    ln -sf "$DATA_DIR" "$APP_CODE/data"
fi

# Run conflict/health checker
if [ -f "$CHECKER" ]; then
    chmod +x "$CHECKER"
    bash "$CHECKER" "$APP_CODE" || exit 1
fi

PYTHON="$VENV_DIR/bin/python3"
if [ ! -x "$PYTHON" ]; then
    osascript -e "display alert \"LegalPerigee\" message \"First-time setup failed.\n\nOpen Terminal and run:\n  bash '$APP_CODE/setup.sh'\" as critical"
    exit 1
fi

exec arch -arm64 "$PYTHON" "$APP_CODE/window.py"
LAUNCHER
chmod +x "$APP_MACOS/LegalPerigee"

# ── Build DMG ─────────────────────────────────────────────────────────────────
echo "  Building DMG..."
ln -s /Applications "$MAC_STAGE/Applications"

DMG_PATH="$RELEASE_DIR/LegalPerigee-${VERSION}-mac.dmg"
TEMP_DMG="$RELEASE_DIR/.temp_mac.dmg"
rm -f "$DMG_PATH"

# Build DMG directly from folder (no osascript — avoids Finder hangs)
hdiutil create \
    -volname "LegalPerigee $VERSION" \
    -srcfolder "$MAC_STAGE" \
    -ov -format UDZO \
    -fs HFS+ \
    "$DMG_PATH" > /dev/null 2>&1

MAC_SIZE=$(du -sh "$DMG_PATH" | cut -f1)
echo "  ✅ macOS DMG: $DMG_PATH ($MAC_SIZE)"


# ═══════════════════════════════════════════════════════════════════════════════
# Windows — Self-contained folder package
# ═══════════════════════════════════════════════════════════════════════════════
echo ""
echo "🪟  Building Windows package..."

WIN_DEST="$WIN_STAGE/LegalPerigee"
mkdir -p "$WIN_DEST"

# Copy all project files
rsync -a \
    --exclude ".venv" \
    --exclude ".git" \
    --exclude "__pycache__" \
    --exclude "*.pyc" \
    --exclude ".DS_Store" \
    --exclude "releases" \
    --exclude "node_modules" \
    --exclude "dist" \
    --exclude "data/*.db" \
    --exclude "*.repair_backup" \
    "$PROJECT_DIR/" "$WIN_DEST/"

# Create a friendly Windows README
cat > "$WIN_DEST/INSTALL.txt" << 'WINTXT'
═══════════════════════════════════════════════════════
  ⚖  LegalPerigee v1.1 — Windows Installation
  Legal Case Intelligence Platform
═══════════════════════════════════════════════════════

QUICK START
───────────
1. Right-click "setup.ps1" in this folder
2. Select "Run with PowerShell"
3. Allow it to install dependencies (~2-5 minutes)
4. A LegalPerigee shortcut appears on your Desktop

If you see a "Run anyway" prompt, click it — the script
is safe and open-source.

REQUIREMENTS
────────────
• Windows 10 or 11 (64-bit)
• Internet connection (for first-time setup only)
• Python 3.9+ (auto-installed if missing)
• Edge WebView2 (auto-installed if missing)

FIRST LAUNCH
────────────
Enter your Anthropic API key in the sidebar.
Get a free key at: console.anthropic.com → API Keys

SUPPORT
───────
Logs: %TEMP%\LegalPerigee_setup.log
Data: %LOCALAPPDATA%\LegalPerigee\

═══════════════════════════════════════════════════════
WINTXT

# Zip the Windows package
WIN_ZIP="$RELEASE_DIR/LegalPerigee-${VERSION}-windows.zip"
cd "$WIN_STAGE"
zip -r "$WIN_ZIP" "LegalPerigee/" -x "*/\.*" > /dev/null 2>&1
cd "$PROJECT_DIR"

WIN_SIZE=$(du -sh "$WIN_ZIP" | cut -f1)
echo "  ✅ Windows ZIP: $WIN_ZIP ($WIN_SIZE)"


# ═══════════════════════════════════════════════════════════════════════════════
# Summary
# ═══════════════════════════════════════════════════════════════════════════════
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🎉  Release v$VERSION ready for distribution"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "  📁 Release folder: $RELEASE_DIR"
echo ""
echo "  🍎 macOS:   LegalPerigee-${VERSION}-mac.dmg  ($MAC_SIZE)"
echo "     → User opens DMG, drags to Applications, double-clicks"
echo "     → First launch: installs deps automatically (~2 min)"
echo ""
echo "  🪟 Windows: LegalPerigee-${VERSION}-windows.zip  ($WIN_SIZE)"
echo "     → User unzips, right-clicks setup.ps1 → Run with PowerShell"
echo "     → Installs deps, creates Desktop shortcut automatically"
echo ""
echo "  ✅ Both packages include all source code — no project folder needed"
echo "  ✅ Both require only an Anthropic API key to start using"
echo ""

# Reveal in Finder
open "$RELEASE_DIR" 2>/dev/null || true
