"""
LegalPerigee — native desktop window launcher.

Starts Streamlit on a background port, then opens the app in a
native macOS WKWebView window (no browser tabs, no address bar).
"""

import os
import signal
import subprocess
import sys
import time
import urllib.request
import warnings

# Silence urllib3 / LibreSSL noise
warnings.filterwarnings("ignore")
os.environ["PYTHONWARNINGS"] = "ignore"

PORT = 8501
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))

# ── Load .env (non-sensitive config only) ─────────────────────────────────────
env_file = os.path.join(PROJECT_DIR, ".env")
if os.path.exists(env_file):
    with open(env_file) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                k = k.strip()
                if k != "ANTHROPIC_API_KEY" and v.strip():  # never load key from file
                    os.environ.setdefault(k, v.strip())

# ── Load ANTHROPIC_API_KEY from macOS Keychain ────────────────────────────────
sys.path.insert(0, PROJECT_DIR)
try:
    from utils.keychain import load_key
    keychain_key = load_key("ANTHROPIC_API_KEY")
    if keychain_key:
        os.environ["ANTHROPIC_API_KEY"] = keychain_key
except Exception:
    pass  # keyring not available; user will enter key in sidebar

# ── Kill any existing instance on the port ────────────────────────────────────
try:
    result = subprocess.run(
        ["lsof", "-ti", f":{PORT}"],
        capture_output=True, text=True,
    )
    for pid in result.stdout.split():
        os.kill(int(pid), signal.SIGKILL)
    time.sleep(0.4)
except Exception:
    pass

# ── Start Streamlit in background ─────────────────────────────────────────────
streamlit_bin = os.path.join(os.path.dirname(sys.executable), "streamlit")
log_path = os.path.expanduser("~/Library/Logs/LegalPerigee.log")
os.makedirs(os.path.dirname(log_path), exist_ok=True)

log_file = open(log_path, "a")
proc = subprocess.Popen(
    [
        streamlit_bin, "run",
        os.path.join(PROJECT_DIR, "gui.py"),
        "--server.headless", "true",
        "--server.port", str(PORT),
        "--server.address", "localhost",
        "--server.runOnSave", "false",       # disable auto-reload on file changes
        "--server.fileWatcherType", "none",  # stop watching files entirely
        "--browser.gatherUsageStats", "false",
        "--logger.level", "error",
    ],
    stdout=log_file,
    stderr=log_file,
    cwd=PROJECT_DIR,
)

# ── Wait for server to respond (up to 20 s) ───────────────────────────────────
url = f"http://localhost:{PORT}"
started = False
for _ in range(40):
    try:
        urllib.request.urlopen(url, timeout=1)
        started = True
        break
    except Exception:
        time.sleep(0.5)

if not started:
    log_file.write("LegalPerigee: Streamlit failed to start in 20 s\n")
    log_file.flush()
    proc.terminate()
    sys.exit(1)

# ── Open native macOS window ──────────────────────────────────────────────────
import webview  # noqa: E402

window = webview.create_window(
    title="⚖️  LegalPerigee",
    url=url,
    width=1440,
    height=940,
    min_size=(1000, 700),
    background_color="#1a2744",   # matches the app's navy header
    text_select=True,
    zoomable=True,
)


def on_closed():
    """Terminate Streamlit when the window closes."""
    try:
        proc.terminate()
        proc.wait(timeout=3)
    except Exception:
        pass
    log_file.close()


window.events.closed += on_closed

# gui=True required on macOS for WKWebView to run on the main thread
webview.start(gui="cocoa", debug=False)
