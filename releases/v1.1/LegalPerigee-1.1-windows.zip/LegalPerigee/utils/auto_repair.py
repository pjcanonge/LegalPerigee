"""
LegalPerigee Auto-Repair System

Catches exceptions anywhere in the app, sends them to Claude with
the relevant source code context, receives a diagnosis + fix, and
applies the patch automatically.

Usage:
    from utils.auto_repair import capture_error, get_pending_errors, apply_fix

    try:
        risky_operation()
    except Exception as e:
        capture_error(e, context="what was being attempted")
"""

import ast
import hashlib
import os
import sys
import textwrap
import traceback
from datetime import datetime
from pathlib import Path
from typing import Optional

# ── In-memory error store (persists for the session) ─────────────────────────
_error_store: list[dict] = []
_MAX_ERRORS = 50
PROJECT_ROOT = Path(__file__).parent.parent


def _error_id(tb: str) -> str:
    return hashlib.md5(tb.encode()).hexdigest()[:10]


def _read_source_context(filename: str, lineno: int, radius: int = 20) -> str:
    """Read ±radius lines around the error line from a source file."""
    try:
        p = Path(filename)
        if not p.exists() or not p.is_file():
            return ""
        lines = p.read_text().splitlines()
        start = max(0, lineno - radius - 1)
        end   = min(len(lines), lineno + radius)
        numbered = []
        for i, line in enumerate(lines[start:end], start + 1):
            marker = ">>> " if i == lineno else "    "
            numbered.append(f"{marker}{i:4d} | {line}")
        return "\n".join(numbered)
    except Exception:
        return ""


def capture_error(
    exc: Exception,
    context: str = "",
    extra_files: Optional[list[str]] = None,
) -> str:
    """
    Capture an exception and queue it for analysis.

    Args:
        exc: The exception that was caught
        context: Human-readable description of what was being attempted
        extra_files: Additional source files to include for context

    Returns:
        error_id string
    """
    tb_str  = traceback.format_exc()
    err_id  = _error_id(tb_str)

    # Avoid duplicate captures of the same error
    if any(e["id"] == err_id for e in _error_store):
        return err_id

    # Extract file/line from traceback
    frames = traceback.extract_tb(exc.__traceback__) if exc.__traceback__ else []
    primary_file = frames[-1].filename if frames else ""
    primary_line = frames[-1].lineno   if frames else 0

    # Only include project files — skip venv
    project_frames = [
        f for f in frames
        if ".venv" not in f.filename and str(PROJECT_ROOT) in f.filename
    ]

    # Collect source context for all project frames
    source_snippets: dict[str, str] = {}
    for frame in project_frames[-3:]:  # last 3 project frames
        rel = os.path.relpath(frame.filename, PROJECT_ROOT)
        snippet = _read_source_context(frame.filename, frame.lineno)
        if snippet:
            source_snippets[rel] = snippet

    # Extra files the caller wants included
    for ef in (extra_files or []):
        ep = PROJECT_ROOT / ef
        if ep.exists():
            source_snippets[ef] = ep.read_text()[:3000]

    record = {
        "id":             err_id,
        "timestamp":      datetime.utcnow().isoformat() + "Z",
        "exception_type": type(exc).__name__,
        "exception_msg":  str(exc),
        "traceback":      tb_str,
        "context":        context,
        "primary_file":   os.path.relpath(primary_file, PROJECT_ROOT) if primary_file else "",
        "primary_line":   primary_line,
        "source_snippets":source_snippets,
        "diagnosis":      None,   # filled in by analyze()
        "fix":            None,   # filled in by analyze()
        "fixed":          False,
        "status":         "pending",
    }
    _error_store.append(record)
    if len(_error_store) > _MAX_ERRORS:
        _error_store.pop(0)

    return err_id


def get_pending_errors() -> list[dict]:
    return [e for e in _error_store if not e["fixed"]]


def get_all_errors() -> list[dict]:
    return list(_error_store)


def mark_fixed(error_id: str) -> None:
    for e in _error_store:
        if e["id"] == error_id:
            e["fixed"]  = True
            e["status"] = "fixed"


# ── Claude diagnosis ──────────────────────────────────────────────────────────

REPAIR_PROMPT = """You are an expert Python/Streamlit developer maintaining LegalPerigee,
a legal case intelligence platform. An exception has occurred and you must diagnose
and fix it precisely.

## Error Details
Context: {context}
Exception: {exc_type}: {exc_msg}

## Full Traceback
```
{traceback}
```

## Relevant Source Code
{source_context}

## Instructions
1. Diagnose the root cause in 1-2 sentences
2. Provide the exact fix as a SEARCH/REPLACE patch — use the exact existing text
3. The fix must be minimal — change only what is broken
4. If the fix requires multiple files, provide multiple patches

Return ONLY this JSON (no prose, no fences):
{{
  "diagnosis": "Root cause in 1-2 sentences",
  "severity": "critical | high | medium | low",
  "fix_summary": "What the fix does",
  "patches": [
    {{
      "file": "relative/path/from/project/root.py",
      "search": "exact text to find (must be unique in the file)",
      "replace": "replacement text"
    }}
  ],
  "restart_required": true,
  "notes": "Any caveats or follow-up actions"
}}"""


def analyze_error(error_id: str, api_key: Optional[str] = None) -> dict:
    """
    Send an error to Claude for diagnosis and fix.
    Updates the error record in-place and returns the result.
    """
    record = next((e for e in _error_store if e["id"] == error_id), None)
    if not record:
        return {"error": "Error ID not found"}

    key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
    if not key:
        return {"error": "No API key available"}

    import anthropic
    from utils.json_extract import extract_json
    from utils.retry import call_with_retry

    client = anthropic.Anthropic(api_key=key)

    # Build source context section
    source_parts = []
    for fname, snippet in record["source_snippets"].items():
        source_parts.append(f"### {fname}\n```python\n{snippet}\n```")
    source_context = "\n\n".join(source_parts) or "(no source available)"

    prompt = REPAIR_PROMPT.format(
        context      = record["context"] or "No context provided",
        exc_type     = record["exception_type"],
        exc_msg      = record["exception_msg"][:500],
        traceback    = record["traceback"][-3000:],
        source_context = source_context[:6000],
    )

    try:
        response = call_with_retry(
            lambda: client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=2048,
                messages=[{"role": "user", "content": prompt}],
            ),
            label="auto_repair",
        )
        result = {}
        for block in response.content:
            if block.type == "text":
                result = extract_json(block.text) or {}
                break

        record["diagnosis"] = result.get("diagnosis","")
        record["fix"]       = result
        record["status"]    = "diagnosed"
        return result

    except Exception as e:
        record["status"] = f"analysis_failed: {e}"
        return {"error": str(e)}


# ── Apply fix ─────────────────────────────────────────────────────────────────

def apply_fix(error_id: str) -> dict:
    """
    Apply the patches from a diagnosed error.
    Returns {"success": True/False, "files_changed": [...], "error": ...}
    """
    record = next((e for e in _error_store if e["id"] == error_id), None)
    if not record or not record.get("fix"):
        return {"success": False, "error": "No fix available — run analyze first"}

    fix     = record["fix"]
    patches = fix.get("patches", [])
    if not patches:
        return {"success": False, "error": "Fix contains no patches"}

    changed = []
    errors  = []

    for patch in patches:
        rel_path = patch.get("file","")
        search   = patch.get("search","")
        replace  = patch.get("replace","")

        if not rel_path or not search:
            errors.append(f"Invalid patch — missing file or search text")
            continue

        full_path = PROJECT_ROOT / rel_path
        if not full_path.exists():
            errors.append(f"File not found: {rel_path}")
            continue

        original = full_path.read_text()
        if search not in original:
            errors.append(f"Search text not found in {rel_path}:\n{search[:100]}…")
            continue

        # Validate the patched file parses before writing
        patched = original.replace(search, replace, 1)
        if rel_path.endswith(".py"):
            try:
                ast.parse(patched)
            except SyntaxError as se:
                errors.append(f"Patch would introduce syntax error in {rel_path}: {se}")
                continue

        # Write backup then apply
        backup = full_path.with_suffix(full_path.suffix + ".repair_backup")
        backup.write_text(original)
        full_path.write_text(patched)
        changed.append(rel_path)

    if errors:
        return {"success": False, "files_changed": changed, "errors": errors}

    mark_fixed(error_id)
    return {
        "success":       True,
        "files_changed": changed,
        "restart_required": fix.get("restart_required", True),
    }


def restart_server() -> None:
    """Restart the Streamlit server by killing the current process."""
    import signal
    os.kill(os.getpid(), signal.SIGTERM)
