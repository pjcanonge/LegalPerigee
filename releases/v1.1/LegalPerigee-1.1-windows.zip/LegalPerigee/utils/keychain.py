"""
Secure API key storage using macOS Keychain via the `keyring` library.

Keys are stored in the system Keychain (encrypted, never written to any file).
Falls back gracefully if keyring is unavailable.
"""

SERVICE = "LegalPerigee"

try:
    import keyring as _kr
    _KEYRING_AVAILABLE = True
except ImportError:
    _KEYRING_AVAILABLE = False


def save_key(name: str, value: str) -> bool:
    """Store a credential in macOS Keychain. Returns True on success."""
    if not _KEYRING_AVAILABLE or not value:
        return False
    try:
        _kr.set_password(SERVICE, name, value)
        return True
    except Exception:
        return False


def load_key(name: str) -> str:
    """Retrieve a credential from macOS Keychain. Returns '' if not found."""
    if not _KEYRING_AVAILABLE:
        return ""
    try:
        val = _kr.get_password(SERVICE, name)
        return val or ""
    except Exception:
        return ""


def delete_key(name: str) -> None:
    """Remove a credential from macOS Keychain."""
    if not _KEYRING_AVAILABLE:
        return
    try:
        _kr.delete_password(SERVICE, name)
    except Exception:
        pass


def keyring_available() -> bool:
    return _KEYRING_AVAILABLE
